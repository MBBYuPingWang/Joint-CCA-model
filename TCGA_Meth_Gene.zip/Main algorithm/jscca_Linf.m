function [w,v]=jscca_Linf(Data,opts)
ntrain=size(Data.m1,1);
label=opts.label;
% nclass=length(unique(label));
lamtv=opts.lamtv;
%% JSCCA with stability selection
ss_mtx=true(ntrain,1);
    ss_th(1)=20*9;
    ss_th(2)=30*15;
[w,v]=solvejinfscca(Data,label,ss_mtx,lamtv,ss_th);
v=permute(v,[1,3,2]);
end

