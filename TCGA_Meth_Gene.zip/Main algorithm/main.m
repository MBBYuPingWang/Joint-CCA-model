clear;clc;
addpath('code');
load TCGA.mat;
Data.m1=TCGA.meth;
Data.m2=TCGA.gene;
%% Data preprocessing
nclass=length(unique(label));
% Standarization
for i=1:nclass
    ind_temp=(label==i);
    Data.m1(ind_temp,:)=zscore(Data.m1(ind_temp,:));
    Data.m2(ind_temp,:)=zscore(Data.m2(ind_temp,:));
end
%% Joint CCA
opts.lamtv=0.25*18;%Determined by 10-fold cross-validation with a stability criteria
opts.label=label;
[w,v]=jscca_Linf(Data,opts);
supp_w=abs(w)>0;
max_v=max(abs(v),[],2);
supp_v=max_v>0;
Meths=info.meth(supp_w);
cpgs=info.cpg(supp_w);
Genes=info.gene(supp_v);
C=abs(v(supp_v,:))>(repmat(max_v(supp_v,:),1,nclass)-eps);
%% Joint precision matrix estimation
% Calculate covariance matrices
sub_meth=Data.m1(:,supp_w);
sub_gene=Data.m2(:,supp_v);
p1=size(sub_meth,2);
p2=size(sub_gene,2);
p=p1+p2;
S=zeros(p,p,nclass);
for i=1:nclass
    ind_temp=(label==i);
    temp=[sub_meth(ind_temp,:),sub_gene(ind_temp,:)];
    S(:,:,i)=temp'*temp/(sum(ind_temp)-1);
    params.n_sample(i)=sum(ind_temp);
end
% Parameter setting
lams=0.044;%% Determined by 10-fold cross-validation
params.lambda=repmat(lams,p,p,nclass);
lamt=repmat(lams,p,p);
for k=1:nclass
    params.lambda(:,:,k)= params.lambda(:,:,k)-diag(diag(params.lambda(:,:,k)));
    temp=double([supp_w(supp_w);C(:,k)]);
    params.lambda(:,:,k)=params.lambda(:,:,k).*(temp*temp');
end
params.supp_lam=double(params.lambda>0);
% Optimization based on LLA
params.P0=repmat(eye(p),1,1,nclass);
for iter=1:20
    P = mgl_Linf_cd(S,params);
    lam_mcp=max(lamt-max(abs(P)/2,[],3),0);
    params.lambda=repmat(lam_mcp,1,1,nclass).*params.supp_lam;
    params.P0=P;
end
%% Build partial correlation network
nsample=params.n_sample;
Precision=max(abs(P),[],3).*sign(mean(P,3));
dP=sqrt(diag(Precision));
pnet=-diag(dP.^(-1))*Precision*diag(dP.^(-1));
pnet=pnet-diag(diag(pnet));
pnet_cross=pnet(1:200,201:end);
sig_nsample=zeros(p,p);
for i=1:nclass
sig_nsample=sig_nsample+double(abs(P(:,:,i))>0)*nsample(i);
end
z_score=sig_nsample.*(1-pnet.^2).^(-2);
z_score(isnan(z_score))=0;
z_score=sqrt(z_score).*abs(pnet);
p_value = 1-normcdf(z_score);
p_value=p_value*2;
%% FDR control
sym=true(p,p);
sym=triu(sym,1);
psort=sort(p_value(sym));
psort_fdr=psort./(1:length(psort))'*length(psort);
fdr_posi=find(psort_fdr<0.05,1,'last');
p_cut=psort(fdr_posi);
p_cross=p_value(1:180,181:end)<p_cut;
p_temp=p_value(1:180,181:end);
p_single=p_temp(p_cross);
[meth,gene]=ind2sub([180,215],find(p_cross));
GM_asso(:,1)=cpgs(meth);
GM_asso(:,2)=Meths(meth);
GM_asso(:,3)=Genes(gene);
GM_asso(:,4:7)=num2cell(double(C(gene,:)));
GM_asso(:,8)=num2cell(p_single);
GM_asso(:,9)=num2cell(meth);
GM_asso(:,10)=num2cell(gene);








