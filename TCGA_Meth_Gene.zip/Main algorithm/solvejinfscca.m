function [w,v]=solvejinfscca(Data,label,ss_mtx,lamtv0,ss_th)
p1=size(Data.m1,2);p2=size(Data.m2,2);
[~,nss]=size(ss_mtx);
nclass=length(unique(label));
cv_train_1=cell(nclass,1);cv_train_2=cell(nclass,1);ptw=cell(nclass,1);nc=zeros(nclass,1);
ntr=zeros(nclass,nss);
for i=1:nclass
    ind_temp=(label==i);
    cv_train_1{i}=Data.m1(ind_temp,:);
    cv_train_2{i}=Data.m2(ind_temp,:);
    ptw{i}=double(ss_mtx(ind_temp,:));
    nc(i)=sum(ind_temp);
    ntr(i,:)=sum(repmat(ind_temp,1,nss)&ss_mtx);
end
% Initialize the loading vector
% v0=svds_ssinitial(X,Y,ss_th,nss);
v0=randn(p2,nss);
v=repmat(v0,1,1,nclass);
v=vnorm(v);
for ii=1:200
    lam1=max(p1*0.5/1.05^ii,ss_th(1));
    lam2=max(p2*0.5/1.05^ii,ss_th(2));
    lamtv=min(0.1*1.05^ii,lamtv0);
    w=zeros(p1,nss);
    for ic=1:nclass
        w=w+cv_train_1{ic}'*((cv_train_2{ic}*v(:,:,ic)).*ptw{ic}./repmat(ntr(ic,:),nc(ic),1));
    end
    w=soft(w,fix(lam1));
    for ic=1:nclass
        wr=cv_train_1{ic}*w.*ptw{ic};
%         ./repmat(sqrt(sum(wr.^2)),nc(ic),1)
        v(:,:,ic)=cv_train_2{ic}'*(wr./repmat(ntr(ic,:),nc(ic),1));
    end
    
    v=vsoft(v,fix(lam2));
    if max(abs(v(:)))>0
    v=vinf(v,lamtv);
    end
    v=vnorm(v);
end
end

function y=soft(x,lambda)
[n,k]=size(x);
temp=sort(abs(x),'descend');
th=temp(lambda+1,:);
y=sign(x).*max(abs(x)-repmat(th,n,1),0);
% y=half(x,th);
ny=sqrt(sum(y.^2));
y(:,ny>0)=y(:,ny>0)./repmat(ny(ny>0),n,1);
end

function v=vsoft(x,lam)
[n,k,nc]=size(x);
th_pos=fix(lam);
th_pos=repmat(th_pos,1,k*nc)+(1:n:k*n*nc);
x=reshape(x,n,k*nc,1);
temp=sort(abs(x),'descend');
th=temp(th_pos);
y=sign(x).*max(abs(x)-repmat(th,n,1),0);
v=reshape(y,n,k,nc);
end

function v=vinf(x,lam)
[n,k,nc]=size(x);
lam_mtx=sum(abs(x)>0,3)*lam/nc;
lam_mtx=reshape(lam_mtx,n*k,1);
x=reshape(x,n*k,nc);
y=L1inf_rw(x,lam_mtx,1e6);
v=reshape(y,n,k,nc);
end


function v=vnorm(x)
[n,k,nc]=size(x);
fnorm=sqrt(sum(sum(x.^2,3),1));
v=x;
v(:,fnorm>0,:)=x(:,fnorm>0,:)./repmat(fnorm(fnorm>0),n,1,nc);
end

