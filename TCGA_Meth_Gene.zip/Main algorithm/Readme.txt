To run the code: First, download the raw data from TCGA, and preprocess the data using the script in the folder Dataprepare. Second, compile the C files, for example:
mex epp.c
mex mex L1inf_rw.c
mex -lmwlapack NewtonD.cpp NewtonD-mex.cpp -output NewtonD.mexw64
(Use the proper extension applicable: mexglx, mexa64 (Linux),
mexmaci32, mexmaci64 (MacOS), mexw32, mexw64 (Windows).)

Finally, run the script main.m

