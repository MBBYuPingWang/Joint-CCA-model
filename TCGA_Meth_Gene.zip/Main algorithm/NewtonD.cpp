//  Revised from the QUIC package written by Cho-Jui.

#include <math.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>
#ifdef GDEBUG
#include "startgdb.h"
#endif

#if defined(LANG_M) || defined(MATLAB_MEX_FILE)
#include <mex.h>
#define MSG mexPrintf
#endif

#ifndef MSG
#define MSG printf
#endif

#define EPS (double(2.22E-16))
//#define EPS ((double)0x3cb0000000000000)

#if !defined(LANG_R) && defined(_WIN32)
#define dpotrf_ dpotrf
#define dpotri_ dpotri
#endif

// It would be preferable to use an include such as lapack.h.  Except
// lapack.h is not available from the octave or liblapack-dev packages...
extern "C" {
    void dpotrf_(char* uplo, ptrdiff_t* n, double* A, ptrdiff_t* lda,
            ptrdiff_t* info);
    void dpotri_(char* uplo, ptrdiff_t* n, double* A, ptrdiff_t* lda,
            ptrdiff_t* info);
}

typedef struct {
    unsigned short i;
    unsigned short j;
} ushort_pair_t;

static inline void CoordinateDescentUpdate(
        unsigned long p, unsigned long K, const double* const S, const double* const Lambda,
        const double* X, const double* W, double* U, double* D, const bool* freeset,
        unsigned long i, unsigned long j, double& normD, double& diffD)
{
    unsigned long ip = i*p;
    unsigned long jp = j*p;
    unsigned long ij = ip + j;
    double a=0;
    double b=0;
    double lamt=0;
    for(unsigned long m=0;m<K;m++){
        unsigned long cm=m*p*p;
        if(freeset[ij+cm]){
            a += W[ij+cm]*W[ij+cm];
            if (i != j)
                a += W[ip+i+cm]*W[jp+j+cm];
            
            b += S[ij+cm] - W[ij+cm];
            for (unsigned long k = 0; k < p ; k++)
                b += W[ip+k+cm]*U[k*p+j+cm];
        }
        lamt+=Lambda[ij+cm];
    }
    double l = lamt/a;
    double c = X[ij] + D[ij];
    double f = b/a;
    double mu;
    normD -= fabs(D[ij]);
    if (c > f) {
        mu = -f - l;
        if (c + mu < 0.0) {
            mu = -c;
            D[ij] = -X[ij];
        } else {
            D[ij] += mu;
        }
    } else {
        mu = -f + l;
        if (c + mu > 0.0) {
            mu = -c;
            D[ij] = -X[ij];
        } else {
            D[ij] += mu;
        }
    }
    diffD += fabs(mu);
    normD += fabs(D[ij]);
    if (mu != 0.0) {
        for (unsigned long m = 0; m < K; m++){
            unsigned long cm=m*p*p;
            if(freeset[ij+cm]){
            for (unsigned long k = 0; k < p; k++){
                    U[ip+k+cm] += mu*W[jp+k+cm];
                }
            }
        }
        if (i != j) {
            for (unsigned long m = 0; m < K; m++){
                unsigned long  cm=m*p*p;
                if(freeset[ij+cm]){
                for (unsigned long k = 0; k < p; k++){
                        U[jp+k+cm] += mu*W[ip+k+cm];
                    }
                }
            }
        }
    }
}


extern "C"
        void NewtonD(uint32_t& p, uint32_t& K, const double* S, double* Lambda0, bool* freeset, double& tol, double* X, double* D, double* W,  uint32_t& cdIter)
{
#ifdef GDEBUG
    startgdb();
#endif
    
    
    double timeBegin = clock();
    double cdSweepTol = 0.05;
    double sigma = 0.001;
    double* U = (double*) malloc(p*p*K*sizeof(double));
    double* Lambda;
    Lambda = Lambda0;
    ushort_pair_t* activeSet = (ushort_pair_t*)
    malloc(p*(p+1)/2*sizeof(ushort_pair_t));
    
    double normD = 0.0;
    double diffD = 0.0;
    
    // Compute the active set and the minimum norm subgradient:
    unsigned long numActive = 0;
    memset(U, 0, p*p*K*sizeof(double));
    memset(D, 0, p*p*sizeof(double));
    for (unsigned long k = 0, i = 0; i < p; i++, k += p) {
        for (unsigned long j = 0; j <= i; j++) {
            double g = 0;
            double lamt=0;
            for (unsigned long m = 0; m < K; m++){
                unsigned long  cm=m*p*p;
                if(freeset[k+j+cm]){
                    g+=S[k+j+cm] - W[k+j+cm];
                }
                lamt+=Lambda[k+j+cm];
            }
            if (fabs(X[k+j])> 0.0 || (fabs(g) > lamt)) {
                activeSet[numActive].i = (unsigned short) i;
                activeSet[numActive].j = (unsigned short) j;
                numActive++;
            }
        }
    }
    for (unsigned long cdSweep = 1; cdSweep <= cdIter;
    cdSweep++) {
        diffD = 0.0;
        
        for (unsigned long i = 0; i < numActive; i++ ) {
            unsigned long j = i + rand()%(numActive - i);
            unsigned short k1 = activeSet[i].i;
            unsigned short k2 = activeSet[i].j;
            activeSet[i].i = activeSet[j].i;
            activeSet[i].j = activeSet[j].j;
            activeSet[j].i = k1;
            activeSet[j].j = k2;
        }
        
        for (unsigned long l = 0; l < numActive; l++) {
            unsigned long i = activeSet[l].i;
            unsigned long j = activeSet[l].j;
            CoordinateDescentUpdate(p,K, S, Lambda, X, W,
                    U, D, freeset, i, j, normD,
                    diffD);
            if (diffD <= normD*cdSweepTol)
                break;
        }
    }
    double elapsedTime = (clock() - timeBegin)/CLOCKS_PER_SEC;
}
