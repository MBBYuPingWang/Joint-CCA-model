function [P,logdet,Loss,DF] = mgl_Linf_cd(S,params)
% set up the params
[n,n,K] = size(S);
params = setParms(params);
lambda = params.lambda;
Cset=params.supp_lam;
for k=1:K
  Cset(:,:,k)=Cset(:,:,k)+eye(n);  
end
P = params.P0;

funVal = [];
R = zeros(n,n,K);
B = R;
for k = 1:K
    [R(:,:,k),info] = chol(P(:,:,k));
    if info > 0
        error('%d not positive definite', k);
    end
    invR = inv(R(:,:,k));
    B(:,:,k) = invR*invR';
end
tic
[fobjp, l1normX] = computLogDet(P, S, R, lambda);
iterTime(1) = toc;
funVal(1) = fobjp;
iter = 1;
% main loop
while (1)
    iter = iter+1;
    tic
    % compute B
    if iter ~= 2
        for k = 1:K
            invR = inv(R(:,:,k));
            B(:,:,k) = invR*invR';
        end
    end
    G = S - B;
    dflag = 0;
    %freeset
    cdX0=sign(mean(P,3)).*max(abs(P),[],3);
    D0 = NewtonD(S,lambda,Cset,1e-6, fix(iter/3+1),cdX0,B);
    D=repmat(D0+triu(D0,1)',1,1,K);
    for k=1:K
       D(:,:,k)=D(:,:,k).*Cset(:,:,k);
    end
    if norm(D(:),'inf') < params.Dtol
        %         fprintf('Step size is too small: ddr %5.2e\n', norm(D(:),'inf'));
        dflag = 1;
    end
    
    %linesearch
    alpha = 64;
    PW = P+D;
    l1normXD = sum(abs(PW(:)).*lambda(:));%%%%%%%%%%%%%%%%%%%%%%%%%%%% recalculate
    
    trdg = 0;
    
    for k = 1:K
        t1 = G(:,:,k);
        t2 = D(:,:,k);
        trdg = trdg + t1(:)'*t2(:);
    end
    
    fobjp1 = 1e15;

    
    for liter = 1 : params.maxlineiter
        W = P+alpha*D;
        flag = 0;
        for k = 1:K
            [Tz,info] = chol(W(:,:,k));
            if info > 0
                flag = 1;
                break;
            end
            R(:,:,k) = Tz;
        end
        if flag == 1
            alpha = alpha/2;
            continue;
        end
        [fobj, l1normX1] = computLogDet(W, S, R, lambda);
        if fobj <= fobjp + alpha*params.sigma*(trdg + l1normXD - l1normX);
            l1normX = l1normX1;
            break;
        end
        if fobjp1 < fobj
            l1normX = l1normX1;
            break
        end
        fobjp1 = fobj;
        alpha = alpha/2;
    end
    P = W;
    iterTime(iter)=toc;
    funVal(iter) = fobj;
    if dflag && params.NewtonStop~=4
        break;
    end
    fobjp = fobj;
    
    if params.NewtonStop == 1 && isfield(params,'NewtonObj')
        if funVal(iter) <= params.NewtonObj || abs(funVal(iter) - params.NewtonObj) < 1e-10
            break;
        end
    elseif params.NewtonStop == 2
        if(abs(funVal(iter) - funVal(iter-1)) <= params.Newtontol*abs(funVal(iter-1))) || norm(D(:),'inf') <  params.Dtol
            break;
        end
    end
    if iter>params.maxiter
        break;
    end
end
for k = 1:K
    invR = inv(R(:,:,k));
    B(:,:,k) = invR*invR';
end
DF=max(abs(P),[],3)>1e-6;
DF=sum(DF(:));
Loss=computLoglike(P, S, R,params.n_sample);
logdet=computLogdetmin(S,R);
end


function logdet = computLogdetmin(S,R)
K = size(S,3);
logdet=zeros(K,1);
for k = 1:K
    logdet(k) =  -2*sum(log(diag(R(:,:,k))));
end
end

function fobj = computLoglike(W, S, R, n_sample)
K = size(S,3);
logdet = 0;
trdg = 0;
for k = 1:K
    logdet = logdet + 2*sum(log(diag(R(:,:,k))))*n_sample(k);
    t1 = S(:,:,k);
    t2 = W(:,:,k);
    trdg = trdg + t1(:)'*t2(:)*n_sample(k);
end
fobj = trdg - logdet;
end

function [fobj, l1normX] = computLogDet(W, S, R, lambda)
K = size(S,3);
logdet = 0;
trdg = 0;
for k = 1:K
    logdet = logdet + 2*sum(log(diag(R(:,:,k))));
    t1 = S(:,:,k);
    t2 = W(:,:,k);
    trdg = trdg + t1(:)'*t2(:);
end
l1normX = sum(abs(W(:).*lambda(:)));
fobj = trdg - logdet + l1normX;
end
