// This is the MEX wrapper for NewtonD.  The algorithm is in NewtonD.C.
// mex -lmwlapack NewtonD.cpp NewtonD-mex.cpp -output NewtonD.mexw64

#include <mex.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>

extern "C"
void NewtonD(uint32_t& p, uint32_t& K, const double* S, double* Lambda, bool* freeset, double& tol, double* X, double* D, double* W, uint32_t& cdIter);

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{



    const double* S = mxGetPr(prhs[0]);
    uint32_t p = (uint32_t) mxGetM(prhs[0]);
    uint32_t tp= (uint32_t) mxGetN(prhs[0]);
    uint32_t K=(uint32_t) tp/p;

	double* Lambda = mxGetPr(prhs[1]);
    bool* freeset= (bool*) malloc(p*p*K*sizeof(bool));
    
    double* freeset0 =mxGetPr(prhs[2]);
    for(unsigned long i=0;i<p*p*K;i++){
        if(freeset0[i]>0){
            freeset[i]=1;
        }
        else{
            freeset[i]=0;
        }
            
    }
    double tol = 1e-6;
    if (nrhs > 2) {
	tol = mxGetScalar(prhs[3]);
    }


    
    // Maximum number of Newton ierations (whole matrix update):
    uint32_t cdIter = 3;
    if (nrhs > 3) {
	cdIter = (uint32_t) mxGetScalar(prhs[4]);
    }
	double* X = mxGetPr(prhs[5]);
	double* W = mxGetPr(prhs[6]);


    double* D;
// 	mwSize dims[] = {int32_t(p), int32_t(p)};
// 	mxArray* tmp = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
    plhs[0] = mxCreateDoubleMatrix( p, p, mxREAL);
// 	X = (double*) mxGetPr(tmp);
// 	if (nlhs > 0)
	    D = mxGetPr(plhs[0]);
memset(D, 0, p*p*sizeof(double));

    NewtonD(p, K, S, Lambda, freeset, tol, X, D, W, cdIter);
}
