function [y,yn,filter]=mepro(x,xn,p1)
p=size(x,1);n1=size(x,1);n2=size(xn,1);
z=[x;xn];
filter=sum(isnan(x))<0.05*p;
z(:,filter)=knnimpute(z(:,filter)')';
x=z(1:n1,:);
xn=z(n1+1:end,:);
tstd=std(x(:,filter));
filter(filter)=tstd>p1;
y=x;
yn=xn;
