clear;clc;
load info.mat
load meth270gene450.mat;
%% gene expression preprocessing
p1=0.5;p2=0;
[A.brca,filter1]=gepro(A.brca',p1);
[A.coad,filter2]=gepro(A.coad',p1);
[A.lusc,filter3]=gepro(A.lusc',p1);
[A.ov,filter4]=gepro(A.ov',p1);
filter=filter1&filter2&filter3&filter4;
TCGA.gene=[A.brca(:,filter);A.coad(:,filter);A.lusc(:,filter);A.ov(:,filter)];
info.gene=info.gene(filter);
label=ones(size(A.brca,1),1);
label=[label;2*ones(size(A.coad,1),1)];
label=[label;3*ones(size(A.lusc,1),1)];
label=[label;4*ones(size(A.ov,1),1)];
load menormal.mat
%% methylation preprocessing
p1=0.05;
[B.brca,A.brca,filter1]=mepro(B.brca',A.brca',p1);
[B.coad,A.coad,filter2]=mepro(B.coad',A.coad',p1);
[B.lusc,A.lusc,filter3]=mepro(B.lusc',A.lusc',p1);
[B.ov,A.ov,filter4]=mepro(B.ov',A.ov',p1);
filter=filter1&filter2&filter3&filter4;
TCGA.meth=[B.brca(:,filter);B.coad(:,filter);B.lusc(:,filter);B.ov(:,filter)];
menormal=[A.brca(:,filter);A.coad(:,filter);A.lusc(:,filter);A.ov(:,filter)];
nmeth=size(TCGA.meth,2);
info.meth=info.meth(filter);
info.cpg=info.cpg(filter);
filter=false(nmeth,1);
for i=1:size(TCGA.meth,2)
    [h,p]=ttest2(TCGA.meth(:,i),menormal(:,i));
    if p<0.05
        filter(i)=true;
    end
end
TCGA.meth=TCGA.meth(:,filter);

info.meth=info.meth(filter);
info.cpg=info.cpg(filter);

save TCGA.mat TCGA info label
