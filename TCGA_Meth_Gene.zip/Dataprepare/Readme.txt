The raw data can be downloaded from The Cancer Genome Altas http://cancergenome.nih.gov/.

We recommed to use TCGA2STAT toolbox to download the data. An example of R code is given in  tcga_4_cancer_normal.R and tcga_4_cancer_tumor.R