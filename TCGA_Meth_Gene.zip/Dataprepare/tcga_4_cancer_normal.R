library('TCGA2STAT')
library('R.matlab')
me.normal<-list()
meth <- getTCGA(disease="BRCA", data.type="Methylation", type="27K")
meth.bytype<-SampleSplit(meth$dat)
me.normal$brca<-meth.bytype$normal
rm(meth.bytype)

meth <- getTCGA(disease="COAD", data.type="Methylation", type="27K")
meth.bytype<-SampleSplit(meth$dat)
me.normal$coad<-meth.bytype$normal
rm(meth.bytype)

meth <- getTCGA(disease="LUSC", data.type="Methylation", type="27K")
meth.bytype<-SampleSplit(meth$dat)
me.normal$lusc<-meth.bytype$normal
rm(meth.bytype)

meth <- getTCGA(disease="OV", data.type="Methylation", type="27K")
meth.bytype<-SampleSplit(meth$dat)
me.normal$ov<-meth.bytype$normal
rm(meth.bytype)

writeMat("menormal.mat", B=me)
