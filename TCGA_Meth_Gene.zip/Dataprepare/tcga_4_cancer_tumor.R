library('TCGA2STAT')
ge<-list()
me<-list()
seq <- getTCGA(disease="BRCA", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="BRCA", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$brca<-m1$X
  me$brca<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="BLCA", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="BLCA", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$blca<-m1$X
  me$blca<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)


seq <- getTCGA(disease="LGG", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="LGG", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$lgg<- m1$X
me$lgg<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="CESC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="CESC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$cesc<-m1$X
  me$cesc<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="COAD", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="COAD", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$coad<-m1$X
  me$coad<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)


seq <- getTCGA(disease="GBM", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="GBM", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$gbm<- m1$X
me$gbm<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="HNSC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="HNSC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$hnsc<- m1$X
me$hnsc<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)


seq <- getTCGA(disease="KIRC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="KIRC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$kirc<- m1$X
  me$kirc<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="KIRP", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="KIRP", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$kirp<-m1$X
  me$kirp<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="LIHC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="LIHC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$brca<-m1$X
  me$brca<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)



seq <- getTCGA(disease="LUAD", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="LUAD", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$luad<- m1$X
me$luad<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="LUSC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="LUSC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$lusc<- m1$X
  me$lusc<- m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="OV", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="OV", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$ov<-m1$X
  me$ov<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="PRAD", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="PRAD", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$prad<-m1$X
  me$prad<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="SKCM", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="SKCM", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$skcm<-m1$X
  me$skcm<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="STAD", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="STAD", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
  ge$stad<-m1$X
  me$stad<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)



seq <- getTCGA(disease="THCA", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="THCA", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$thca<-m1$X
me$thca<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

seq <- getTCGA(disease="UCEC", data.type="mRNA_Array", type="G450")
meth <- getTCGA(disease="UCEC", data.type="Methylation", type="27K")
seq.bytype<-SampleSplit(seq$dat)
seq.pt<-seq.bytype$primary.tumor
meth.bytype<-SampleSplit(meth$dat)
meth.pt<-meth.bytype$primary.tumor
m1 <- OMICSBind(dat1 = seq.pt, dat2 = meth.pt)
if(length(m1$X)>0)
{
ge$ucec<-m1$X
me$ucec<-m1$Y
}
rm(seq,meth,seq.bytype,seq.pt,meth.bytype,meth.pt,m1)

writeMat("meth270gene450.mat", A=ge,B=me)
