function [y,filter]=gepro(x,p1)
p=size(x,1);
filter=sum(isnan(x))<0.05*p;
x(:,filter)=knnimpute(x(:,filter)')';
tstd=std(x(:,filter));
filter(filter)=tstd>p1;
y=x;

