clear;clc;close all;
% Initialization
c=clock;
rng(c(6));% random seed
num_trail=100; % number of replications
d=2; % dimension of the data
nfold=10; % number of folds in cross validation

for i=7:7
n_sample=16*2^(i-1);
for k=1:num_trail
    %% Data generation
    % test data
    test_x=rand(1000,d); 
    ttr=2*(test_x-0.5);
    dis=sqrt(sum(ttr.^2,2));
    test_y=max(1-dis,0).^6.*(35*dis.^2+18*dis+3);
    % training data
    train_x=rand(n_sample,d);
    tsr=2*(train_x-0.5);
    dis=sqrt(sum(tsr.^2,2));
    train_y=max(1-dis,0).^6.*(35*dis.^2+18*dis+3)+0.1*randn(n_sample,1);
    [TestRMSE(i,1:2,k),MSF(i,1:2,k),TrainMT(i,1:2,k)]=LSF_eval(train_x,train_y,test_x,test_y,nfold,'Sobol');% Sobol sequences
    [TestRMSE(i,3:4,k),MSF(i,3:4,k),TrainMT(i,3:4,k)]=LSF_eval(train_x,train_y,test_x,test_y,nfold,'Rand'); % randomly drawn from [0,1]^d
    [TestRMSE(i,5:6,k),MSF(i,5:6,k),TrainMT(i,5:6,k)]=LSF_eval(train_x,train_y,test_x,test_y,nfold,'dRand'); %randomly drawn from the data
    [TestRMSE(i,7,k),MSF(i,7,k),TrainMT(i,7,k)]=RLS(train_x,train_y,test_x,test_y,nfold);
end

end









