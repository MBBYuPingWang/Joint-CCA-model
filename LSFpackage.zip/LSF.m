function [reg_coef,Selected_Features,tau,Training_time]=LSF(train_x,train_y,nfold,ftype)
warning off
%%
% Function: Learning with selected features
%
%% Input parameters:
%
%  train_x:   Matrix of size m x n, m for sample size and n for dimension
%  train_y:   Vector of size m x 1
%  nfold:     Number of folds in cross validation
%  ftype:     Type of features
%
%% Output parameters:
%  Selected_Features:  Selcted features using cross validation
%  reg_coef:           Regression Coefficient
%  Training_time:      Training time
%  tau
%% Related papers
%
% [1]  Shao-Bo Lin, Jian Fang, Xiangyu Chang, Learning with Selected Features, submitted, 2017.
%
% For any problem, please contact with Jian Fang via jianfang86@gmail.com

n=size(train_x,1);
for log2n=1:18
    n_feature=fix(sqrt(n/sqrt(log2(n)))*(2^(log2n/3-2)))+1;
    ker_ct{log2n}=getfeature(train_x,n_feature,ftype);
end
cv0=1e5;
%% Training
tic;
for log2n=1:18
    for log2s=1:12
        cv=scltrain(train_x,train_y,ker_ct{log2n},nfold,log2s,1e-10);
        if cv<cv0
            cv0=cv;bs=log2s;bn=log2n;
        end
    end
end
Training_time=toc;
Selected_Features=ker_ct{bn};
[ker_mtx,tau]=getkernel(train_x,ker_ct{bn},bs);
reg_coef=(ker_mtx'*ker_mtx+1e-10*eye(size(ker_mtx,2)))\(ker_mtx'*train_y);




function [cv,sigma]=scltrain(train_x,train_y,ker_ct,nfold,tau,lambda)
Sample=size(train_x,1);nsf=fix(Sample/nfold);cvt=zeros(nfold,1);
ker_mtx=getkernel(train_x,ker_ct,tau);
for nf=1:nfold
    indsample=ones(Sample,1);indsample((nf-1)*nsf+1:nf*nsf)=0;indsample=logical(indsample);
    u_okcd=(ker_mtx(indsample,:)'*ker_mtx(indsample,:)+lambda*eye(size(ker_mtx(indsample,:),2)))\(ker_mtx(indsample,:)'*train_y(indsample));
    if max(u_okcd)==Inf
        cvt(nf)=Inf;
    else
        cvt(nf)=mse(ker_mtx(~indsample,:)*u_okcd-train_y(~indsample));
    end
end
cv=mean(cvt);
sigma=std(cvt);

function y=mse(x)
y=mean(x.^2);


function [ker_mtx,tau]=getkernel(train_x,ker_ct,log2s)
tau=2^(log2s-11);
mul=repmat(sum(train_x.^2,2),1,size(ker_ct,1))+repmat(sum(ker_ct.^2,2)',size(train_x,1),1)-2*train_x*ker_ct';
ker_mtx=exp(-mul/tau);


function  ker_ct=getfeature(train_x,n_feature,ftype)
[N,d]=size(train_x);
if strcmp(ftype,'Rand')
    feature_ct=rand(n_feature,d);
    ker_ct=feature_ct;
elseif strcmp(ftype,'dRand')
    %% option 2
    rr=randperm(N);
    ker_ct=train_x(rr(1:min(n_feature,N)),:);
elseif strcmp(ftype,'Sobol')
    P = sobolset(d,'Skip',1e5,'Leap',1e3);
    P = scramble(P,'MatousekAffineOwen');
    feature_ct= net(P,n_feature);
    ker_ct=feature_ct;
else
    ker_ct=train_x;
end

