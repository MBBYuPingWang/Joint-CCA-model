function TestRMSE=LSF_test(test_x,test_y,Selected_Features,tau,reg_coef)
ker_mtxt=getkernel(test_x,Selected_Features,tau);
TestRMSE=sqrt(mse(ker_mtxt*reg_coef-test_y));

function ker_mtx=getkernel(train_x,ker_ct,tau)
mul=repmat(sum(train_x.^2,2),1,size(ker_ct,1))+repmat(sum(ker_ct.^2,2)',size(train_x,1),1)-2*train_x*ker_ct';
ker_mtx=exp(-mul/tau);


function y=mse(x)
y=mean(x.^2);

