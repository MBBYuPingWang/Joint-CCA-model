function [TestRMSE,n_SF,training_time]=RLS(train_x,train_y,test_x,test_y,nfold)
warning off
N=size(train_x,1);
cv0=1e5;
%% Training
tic;
    for log2s=1:12
        for log2l=1:20
            lambda=2^(1-log2l)*N;
           cv=scltrain(train_x,train_y,train_x,nfold,log2s,lambda);
            if cv<cv0
                cv0=cv;bs=log2s;bl=lambda;
            end
        end
    end
training_time=toc;
n_SF=size(samp_ct,1);
ker_mtx=getkernel(train_x,train_x,bs);
u_okcd=(ker_mtx'*ker_mtx+bl*eye(size(ker_mtx,2)))\(ker_mtx'*train_y);
ker_mtxt=getkernel(test_x,train_x,bs);
TestRMSE=sqrt(mse(ker_mtxt*u_okcd-test_y));



function [cv,sigma]=scltrain(train_x,train_y,ker_ct,nfold,tau,lambda)
Sample=size(train_x,1);nsf=fix(Sample/nfold);cvt=zeros(nfold,1);
ker_mtx=getkernel(train_x,ker_ct,tau);
for nf=1:nfold
    indsample=ones(Sample,1);indsample((nf-1)*nsf+1:nf*nsf)=0;indsample=logical(indsample);
    u_okcd=(ker_mtx(indsample,:)'*ker_mtx(indsample,:)+lambda*eye(size(ker_mtx(indsample,:),2)))\(ker_mtx(indsample,:)'*train_y(indsample));
    if max(u_okcd)==Inf
        cvt(nf)=Inf;
    else
        cvt(nf)=mse(ker_mtx(~indsample,:)*u_okcd-train_y(~indsample));
    end
end
cv=mean(cvt);
sigma=std(cvt);

function y=mse(x)
y=mean(x.^2);


function ker_mtx=getkernel(train_x,ker_ct,log2s)
tau=2^(log2s-11);
mul=repmat(sum(train_x.^2,2),1,size(ker_ct,1))+repmat(sum(ker_ct.^2,2)',size(train_x,1),1)-2*train_x*ker_ct';
ker_mtx=exp(-mul/tau);


function  ker_ct=getfeature(train_x,n_feature,ftype)
[N,d]=size(train_x);
if strcmp(ftype,'Rand')
    feature_ct=rand(n_feature,d);
    ker_ct=feature_ct;
elseif strcmp(ftype,'dRand')
    %% option 2
    rr=randperm(N);
    ker_ct=train_x(rr(1:min(n_feature,N)),:);
elseif strcmp(ftype,'Sobol')
    P = sobolset(d,'Skip',1e5,'Leap',1e3);
    P = scramble(P,'MatousekAffineOwen');
    feature_ct= net(P,n_feature);
    ker_ct=feature_ct;
else
    ker_ct=train_x;
end



